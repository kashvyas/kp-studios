# Deploy KP Studios on Netlify

1. Push this folder to GitHub, GitLab, or Bitbucket.
2. In Netlify, select **Add new site → Import an existing project**.
3. Choose the repository. Netlify detects Next.js automatically.
4. Keep the build command as `npm run build`; no publish directory is required.
5. Deploy and optionally add a custom domain.

Node.js 22 or newer is required. The hero artwork is packaged locally. Project photography currently uses public source URLs from the original KP Studios Notion site.
